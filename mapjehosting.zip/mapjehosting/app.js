require('dotenv').config(); //This will be used to store private keys
const path = require('path');
const fs = require('fs');
const deployCommands = require('./deploy/deployCommands');
const {
	ActionRowBuilder,
	ButtonBuilder,
	ButtonStyle,
	ChannelType,
	Client,
	Collection,
	EmbedBuilder,
	Events,
	GatewayIntentBits,
	ModalBuilder,
	PermissionFlagsBits,
	PermissionsBitField,
	Partials,
	TextInputBuilder,
	TextInputStyle,
} = require('discord.js');
const getMeme = require('./commands/getMeme/getMeme');
const { readJson, writeJson } = require('./lib/jsonStore');
const { processLevelGain, getRequiredXp, resolveLevelsChannel } = require('./lib/levelingService');
const { addBalance, getBalance, getCrownConfig } = require('./lib/crownService');
const { getSettings } = require('./lib/guildSettings');
const { checkCommandAllowed } = require('./lib/commandRestrictions');
const { migrateGuildConfigs } = require('./lib/migrateConfigs');
const setupWizard = require('./lib/setupWizard');
const roleCategoryService = require('./lib/roleCategoryService');
const minigameService = require('./lib/minigameService');
const { isEconomyEnabled } = require('./lib/economyService');
const {
	drawCard,
	handValue,
	formatHand,
	isBlackjack,
	isBust,
	dealerShouldHit,
} = require('./lib/blackjackService');

const levelsFile = path.join(__dirname, 'data', 'levels.json');
const rewardsFile = path.join(__dirname, 'data', 'roleRewards.json');
const roleMenusFile = path.join(__dirname, 'data', 'roleMenus.json');
const reactionRolesFile = path.join(__dirname, 'data', 'reactionRoles.json');
const levelsChannelFile = path.join(__dirname, 'data', 'levelsChannel.json');
const welcomeConfigFile = path.join(__dirname, 'data', 'welcomeConfig.json');
const countingConfigFile = path.join(__dirname, 'data', 'countingConfig.json');
const crownsConfigFile = path.join(__dirname, 'data', 'crownsConfig.json');
const crownsFile = path.join(__dirname, 'data', 'crowns.json');
const crownsClaimsFile = path.join(__dirname, 'data', 'crownsClaims.json');
const blackjackGamesFile = path.join(__dirname, 'data', 'blackjackGames.json');
const ticketPanelsFile = path.join(__dirname, 'data', 'ticketPanels.json');
const minigamesFile = path.join(__dirname, 'data', 'minigames.json');
const countingSavesFile = path.join(__dirname, 'data', 'countingSaves.json');
const levelCooldownMs = 60_000;
const xpPerMessageMin = 15;
const xpPerMessageMax = 25;
const ENABLE_PRIVILEGED_INTENTS = process.env.ENABLE_PRIVILEGED_INTENTS === 'true';

const BOT_TOKEN = process.env.CLIENT_TOKEN;

const clientIntents = [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.GuildMessageReactions];

if (ENABLE_PRIVILEGED_INTENTS) {
	clientIntents.push(GatewayIntentBits.GuildMembers, GatewayIntentBits.MessageContent);
} else {
	console.warn('Privileged intents are disabled. Enable ENABLE_PRIVILEGED_INTENTS=true only after turning them on in the Discord Developer Portal.');
}

const client = new Client({
	intents: clientIntents,
	partials: [Partials.Message, Partials.Channel, Partials.Reaction, Partials.User],
});

async function ensureLevelsChannel(guild) {
	const allLevelChannels = readJson(levelsChannelFile, {});
	const configuredChannelId = allLevelChannels[guild.id]?.channelId;
	let levelsChannel = configuredChannelId ? guild.channels.cache.get(configuredChannelId) : null;

	if (levelsChannel && levelsChannel.isTextBased()) {
		return levelsChannel;
	}

	if (configuredChannelId && !levelsChannel) {
		const fetchedConfiguredChannel = await guild.channels.fetch(configuredChannelId).catch(() => null);
		if (fetchedConfiguredChannel && fetchedConfiguredChannel.isTextBased()) {
			return fetchedConfiguredChannel;
		}
	}

	levelsChannel = guild.channels.cache.find(channel => channel.name === 'levels' && channel.isTextBased());
	if (levelsChannel) {
		allLevelChannels[guild.id] = { channelId: levelsChannel.id };
		writeJson(levelsChannelFile, allLevelChannels);
		return levelsChannel;
	}

	const fetchedChannels = await guild.channels.fetch().catch(() => null);
	if (fetchedChannels) {
		levelsChannel = fetchedChannels.find(channel => channel && channel.name === 'levels' && channel.isTextBased());
		if (levelsChannel) {
			return levelsChannel;
		}
	}

	const botMember = guild.members.me || await guild.members.fetchMe().catch(() => null);
	if (!botMember?.permissions?.has(PermissionsBitField.Flags.ManageChannels)) {
		console.warn(`Cannot create #levels in guild ${guild.id}: missing ManageChannels permission.`);
		return null;
	}

	try {
		const createdChannel = await guild.channels.create({
			name: 'levels',
			type: ChannelType.GuildText,
			reason: 'Level-up announcements channel',
		});
		allLevelChannels[guild.id] = { channelId: createdChannel.id };
		writeJson(levelsChannelFile, allLevelChannels);
		return createdChannel;
	} catch (err) {
		console.error(`Failed to create #levels in guild ${guild.id}:`, err);
		return null;
	}
}

async function sendLevelUpAnnouncement(guild, user, member, level, rewardMessages) {
	const levelsChannel = await ensureLevelsChannel(guild);
	if (!levelsChannel) {
		console.warn(`No levels channel available in guild ${guild.id}; level-up message suppressed.`);
		return;
	}

	const userDisplay = member?.displayName || member?.user?.username || member?.user?.tag || 'Onbekende gebruiker';
	const levelUpEmbed = new EmbedBuilder()
		.setColor(0xff0000)
		.setTitle('Level up')
		.setDescription(`Gefeliciteerd ${userDisplay}, je hebt level ${level} bereikt.`)
		.setFooter({ text: 'Level systeem' });

	if (rewardMessages.length) {
		levelUpEmbed.addFields({
			name: 'Ontvangen rollen',
			value: rewardMessages.map(roleName => `- ${roleName}`).join('\n'),
		});
	}

	await levelsChannel.send({ content: `<@${user.id}>`, embeds: [levelUpEmbed] }).catch(err => {
		console.error('Failed to send level-up message to levels channel:', err);
	});
}

function isTicketChannel(channel) {
	if (!channel) {
		return false;
	}

	const channelName = channel.name?.toLowerCase() || '';
	const channelTopic = channel.topic?.toLowerCase() || '';
	const parentName = channel.parent?.name?.toLowerCase() || '';
	if (channelName.includes('ticket') || channelTopic.includes('ticket') || parentName.includes('ticket')) {
		return true;
	}

	if (channel.guild) {
		const settings = getSettings(channel.guild.id);
		const ticketCategoryId = settings.channels.ticketCategory;
		if (ticketCategoryId && channel.parentId === ticketCategoryId) {
			return true;
		}
	}
	return false;
}

function getGuildConfig(filePath, guildId, fallback = {}) {
	const allConfigs = readJson(filePath, {});
	return allConfigs[guildId] || fallback;
}

function getCountingSaves(guildId, userId) {
	const all = readJson(countingSavesFile, {});
	return all[guildId]?.[userId] || 0;
}

function setCountingSaves(guildId, userId, amount) {
	const all = readJson(countingSavesFile, {});
	const guildSaves = all[guildId] || {};
	guildSaves[userId] = Math.max(0, amount);
	all[guildId] = guildSaves;
	writeJson(countingSavesFile, all);
	return guildSaves[userId];
}

function addCountingSaves(guildId, userId, amount) {
	return setCountingSaves(guildId, userId, getCountingSaves(guildId, userId) + amount);
}

async function handleCountingMessage(message) {
	const settings = getSettings(message.guild.id);
	const channelId = settings.channels.counting || getGuildConfig(countingConfigFile, message.guild.id, null)?.channelId;
	if (!channelId || message.channel.id !== channelId) {
		return false;
	}
	if (!settings.counting.enabled && settings.channels.counting) {
		return false;
	}
	const config = getGuildConfig(countingConfigFile, message.guild.id, { channelId, lastNumber: 0, lastUserId: null });

	const nextNumber = (config.lastNumber || 0) + 1;
	const trimmed = message.content.trim();
	const guessedNumber = Number(trimmed);

	if (!trimmed || !Number.isInteger(guessedNumber)) {
		return false;
	}

	const isWrongUser = message.author.id === config.lastUserId;
	const isWrongNumber = guessedNumber !== nextNumber;

	if (isWrongUser || isWrongNumber) {
		const saves = getCountingSaves(message.guild.id, message.author.id);
		if (saves > 0) {
			setCountingSaves(message.guild.id, message.author.id, saves - 1);
			await message.react('🛡️').catch(() => null);
			await message.channel.send({
				content: `<@${message.author.id}> gebruikte een save (${saves - 1} over). De count blijft op **${config.lastNumber || 0}**, volgende getal is **${nextNumber}**.`,
			}).catch(() => null);
			await message.delete().catch(() => null);
			return true;
		}

		const allConfigs = readJson(countingConfigFile, {});
		allConfigs[message.guild.id] = {
			channelId,
			lastNumber: 0,
			lastUserId: null,
		};
		writeJson(countingConfigFile, allConfigs);

		const reason = isWrongUser
			? 'mocht niet 2 keer na elkaar tellen'
			: `typte **${guessedNumber}** in plaats van **${nextNumber}**`;
		await message.channel.send({
			content: `❌ <@${message.author.id}> heeft het verpest (${reason}). Het volgende getal is **1**.\nTip: koop saves in de shop met \`/crownshop buysave\` zodat een fout automatisch opgevangen wordt.`,
		}).catch(() => null);
		return true;
	}

	const allConfigs = readJson(countingConfigFile, {});
	allConfigs[message.guild.id] = {
		channelId,
		lastNumber: guessedNumber,
		lastUserId: message.author.id,
	};
	writeJson(countingConfigFile, allConfigs);
	await message.react('✅').catch(() => null);
	return true;
}

async function handleMinigameMessage(message) {
	const state = minigameService.getActiveGame(message.guild.id, message.channel.id);
	if (!state || state.finished) return false;
	if (state.game !== 'wordle' && state.game !== 'hangman') return false;

	const text = message.content.trim().toLowerCase();
	if (!text || /^\s*$/.test(text)) return false;
	if (!/^[a-z]+$/.test(text)) return false;

	if (state.game === 'wordle') {
		if (text.length !== state.answer.length) return false;
		const marks = minigameService.evaluateWordleGuess(state.answer, text);
		state.guesses.push({ word: text, marks, userId: message.author.id });
		const won = marks.every(m => m === 'correct');
		if (won) {
			state.finished = true;
			state.won = true;
			const reward = await minigameService.awardWin(message.guild.id, message.author.id, 'wordle');
			minigameService.setActiveGame(message.guild.id, message.channel.id, null);
			await message.channel.send({
				embeds: [minigameService.buildWordleEmbed(state)],
				content: reward > 0 ? `🎉 <@${message.author.id}> wint en krijgt **${reward}** kroontjes!` : `🎉 <@${message.author.id}> wint!`,
			}).catch(() => null);
			return true;
		}
		if (state.guesses.length >= state.maxGuesses) {
			state.finished = true;
			state.won = false;
			minigameService.setActiveGame(message.guild.id, message.channel.id, null);
		} else {
			minigameService.setActiveGame(message.guild.id, message.channel.id, state);
		}
		await message.channel.send({ embeds: [minigameService.buildWordleEmbed(state)] }).catch(() => null);
		return true;
	}

	if (state.game === 'hangman') {
		if (text.length === 1) {
			if (state.guessed.includes(text) || state.wrong.includes(text)) {
				return false;
			}
			if (state.answer.includes(text)) {
				state.guessed.push(text);
			} else {
				state.wrong.push(text);
			}
		} else if (text.length === state.answer.length) {
			if (text === state.answer) {
				state.guessed = [...new Set(state.answer.split(''))];
			} else {
				state.wrong.push(text);
			}
		} else {
			return false;
		}

		const allRevealed = state.answer.split('').every(ch => state.guessed.includes(ch));
		const dead = state.wrong.length >= minigameService.HANGMAN_MAX_WRONG;
		if (allRevealed) {
			state.finished = true;
			state.won = true;
			const reward = await minigameService.awardWin(message.guild.id, message.author.id, 'hangman');
			minigameService.setActiveGame(message.guild.id, message.channel.id, null);
			await message.channel.send({
				embeds: [minigameService.buildHangmanEmbed(state)],
				content: reward > 0 ? `🎉 <@${message.author.id}> wint en krijgt **${reward}** kroontjes!` : `🎉 <@${message.author.id}> wint!`,
			}).catch(() => null);
			return true;
		}
		if (dead) {
			state.finished = true;
			state.won = false;
			minigameService.setActiveGame(message.guild.id, message.channel.id, null);
		} else {
			minigameService.setActiveGame(message.guild.id, message.channel.id, state);
		}
		await message.channel.send({ embeds: [minigameService.buildHangmanEmbed(state)] }).catch(() => null);
		return true;
	}

	return false;
}

async function maybeSpawnCrown(message) {
	if (isTicketChannel(message.channel)) {
		return;
	}

	const settings = getSettings(message.guild.id);
	const econ = settings.economy;
	const legacyConfig = getCrownConfig(crownsConfigFile, message.guild.id);
	const enabled = econ.enabled || Boolean(legacyConfig?.enabled);
	if (!enabled) {
		return;
	}

	const chancePercent = econ.crownSpawnChance || legacyConfig?.chancePercent || 5;
	if (Math.random() * 100 > chancePercent) {
		return;
	}

	const claimId = `${Date.now()}-${Math.random().toString(16).slice(2, 8)}`;
	const allClaims = readJson(crownsClaimsFile, {});
	allClaims[claimId] = {
		guildId: message.guild.id,
		channelId: message.channel.id,
		messageId: null,
		claimedBy: null,
	};
	writeJson(crownsClaimsFile, allClaims);

	const claimButton = new ActionRowBuilder().addComponents(
		new ButtonBuilder()
			.setCustomId(`crownclaim:${claimId}`)
			.setLabel('Claim kroontje')
			.setStyle(ButtonStyle.Danger),
	);

	const crownEmbed = new EmbedBuilder()
		.setColor(0xb40f0f)
		.setTitle('Kroontje verschenen!')
		.setDescription('Klik op de knop om het kroontje te claimen.');

	const sentMessage = await message.channel.send({ embeds: [crownEmbed], components: [claimButton] }).catch(() => null);
	if (!sentMessage) {
		return;
	}

	allClaims[claimId].messageId = sentMessage.id;
	writeJson(crownsClaimsFile, allClaims);
}

function renderWelcomeMessage(template, member) {
	return (template || 'Welkom {user}, je bent nu lid nummer **{count}**.')
		.replace(/\{user\}/g, `<@${member.id}>`)
		.replace(/\{count\}/g, String(member.guild.memberCount));
}

async function sendWelcomeMessage(member) {
	const settings = getSettings(member.guild.id);
	const welcomeSettings = settings.welcome;
	const channelId = settings.channels.welcome;

	const legacyChannelId = !channelId
		? getGuildConfig(welcomeConfigFile, member.guild.id, null)?.channelId
		: null;
	const effectiveChannelId = channelId || legacyChannelId;

	const enabled = welcomeSettings.enabled || (!channelId && !!legacyChannelId);
	if (!enabled) return;

	const description = renderWelcomeMessage(welcomeSettings.message, member);
	const welcomeEmbed = new EmbedBuilder()
		.setColor(0xb40f0f)
		.setTitle('Welkom!')
		.setDescription(description);

	if (welcomeSettings.mode === 'dm') {
		await member.send({ embeds: [welcomeEmbed] }).catch(err => {
			console.error('Failed to DM welcome message:', err);
		});
		return;
	}

	if (!effectiveChannelId) return;
	const welcomeChannel = member.guild.channels.cache.get(effectiveChannelId)
		|| await member.guild.channels.fetch(effectiveChannelId).catch(() => null);
	if (!welcomeChannel?.isTextBased()) return;

	await welcomeChannel.send({ content: `<@${member.id}>`, embeds: [welcomeEmbed] }).catch(err => {
		console.error('Failed to send welcome message:', err);
	});
}

function loadBlackjackGames() {
	return readJson(blackjackGamesFile, {});
}

function saveBlackjackGames(games) {
	writeJson(blackjackGamesFile, games);
}

function buildBlackjackEmbed(state, revealDealer = false, statusText = '') {
	const playerTotal = handValue(state.playerHand);
	const dealerTotal = revealDealer ? handValue(state.dealerHand) : '??';
	const dealerCards = formatHand(state.dealerHand, !revealDealer);
	const playerCards = formatHand(state.playerHand, false);

	const embed = new EmbedBuilder()
		.setColor(0xb40f0f)
		.setTitle('Blackjack is nu draaiende')
		.setDescription(statusText || 'Hit of stand? Kies wat je wilt doen.');

	embed.addFields(
		{ name: 'Inzet', value: `${state.bet} kroontjes`, inline: true },
		{ name: 'Dealer', value: `${dealerCards}\nTotaal: ${dealerTotal}`, inline: true },
		{ name: 'Jij', value: `${playerCards}\nTotaal: ${playerTotal}`, inline: true },
	);

	return embed;
}

function buildBlackjackButtons(gameId, disabled = false) {
	return new ActionRowBuilder().addComponents(
		new ButtonBuilder().setCustomId(`blackjack:${gameId}:hit`).setLabel('Hit').setStyle(ButtonStyle.Danger).setDisabled(disabled),
		new ButtonBuilder().setCustomId(`blackjack:${gameId}:stand`).setLabel('Stand').setStyle(ButtonStyle.Secondary).setDisabled(disabled),
	);
}

async function resolveBlackjackMessage(interaction) {
	if (interaction?.channel?.messages?.fetch) {
		return interaction.channel.messages.fetch(interaction.message.id).catch(() => interaction.message);
	}

	return interaction.message;
}

async function runBlackjackCountdown(channel, messageId, fallbackMessage, state, seconds = 10) {
	for (let remaining = seconds; remaining >= 1; remaining -= 1) {
		const targetMessage = channel?.messages?.fetch ? await channel.messages.fetch(messageId).catch(() => fallbackMessage) : fallbackMessage;
		if (!targetMessage) {
			console.error('Could not resolve blackjack message for countdown.');
			return;
		}

		await targetMessage.edit({
			content: `Dealer denkt na... resultaat over ${remaining} seconden.`,
			embeds: [buildBlackjackEmbed(state, false, `Dealer denkt na... resultaat over ${remaining} seconden.`)],
			components: [buildBlackjackButtons(state.gameId)],
		}).catch(error => {
			console.error('Failed to edit blackjack countdown message:', error);
		});
		await new Promise(resolve => setTimeout(resolve, 1000));
	}
}

async function settleBlackjackState(interaction, state, reason) {
	let dealerTotal = handValue(state.dealerHand);
	while (dealerShouldHit(state.dealerHand)) {
		state.dealerHand.push(drawCard(state.deck));
		dealerTotal = handValue(state.dealerHand);
	}

	const playerTotal = handValue(state.playerHand);
	const dealerBust = isBust(state.dealerHand);
	const playerBlackjack = isBlackjack(state.playerHand);
	const dealerBlackjack = isBlackjack(state.dealerHand);

	let resultText = 'Gelijkspel.';
	if (playerTotal > 21) {
		resultText = `Je bent busted en verliest ${state.bet} kroontjes.`;
	} else if (dealerBust) {
		addBalance(crownsFile, interaction.guildId, interaction.user.id, state.bet * 2);
		resultText = `Dealer is busted. Je wint ${state.bet} kroontjes.`;
	} else if (playerBlackjack && !dealerBlackjack) {
		addBalance(crownsFile, interaction.guildId, interaction.user.id, Math.ceil(state.bet * 2.5));
		resultText = `Blackjack! Je wint ${Math.ceil(state.bet * 2.5)} kroontjes.`;
	} else if (dealerBlackjack && !playerBlackjack) {
		resultText = `Dealer heeft blackjack. Je verliest ${state.bet} kroontjes.`;
	} else if (playerTotal > dealerTotal) {
		addBalance(crownsFile, interaction.guildId, interaction.user.id, state.bet * 2);
		resultText = `Je hebt gewonnen met ${playerTotal} tegen ${dealerTotal}.`;
	} else if (playerTotal < dealerTotal) {
		resultText = `Dealer wint met ${dealerTotal} tegen ${playerTotal}.`;
	} else {
		addBalance(crownsFile, interaction.guildId, interaction.user.id, state.bet);
		resultText = `Gelijkspel met ${playerTotal}. Je krijgt je inzet terug.`;
	}

	state.finished = true;
	state.reason = reason;

	const games = loadBlackjackGames();
	games[state.gameId] = state;
	saveBlackjackGames(games);

	return {
		embed: buildBlackjackEmbed(state, true, resultText),
		components: [buildBlackjackButtons(state.gameId, true)],
	};
}

async function handleReactionRoleUpdate(reaction, user, shouldAdd) {
	try {
		if (user.bot) {
			return;
		}

		const fetchedReaction = reaction.partial ? await reaction.fetch().catch(() => null) : reaction;
		if (!fetchedReaction?.message?.guild) {
			return;
		}

		const guild = fetchedReaction.message.guild;
		const allReactionRoles = readJson(reactionRolesFile, {});
		const mapping = allReactionRoles[fetchedReaction.message.id];
		if (!mapping || mapping.guildId !== guild.id) {
			return;
		}

		const roleEntry = mapping.roles.find(role => role.emoji === fetchedReaction.emoji.toString());
		if (!roleEntry) {
			return;
		}

		const member = await guild.members.fetch(user.id).catch(() => null);
		if (!member) {
			return;
		}

		const role = guild.roles.cache.get(roleEntry.roleId) || await guild.roles.fetch(roleEntry.roleId).catch(() => null);
		if (!role) {
			return;
		}

		if (shouldAdd) {
			await member.roles.add(role).catch(err => {
				console.error('Failed to add reaction role:', err);
			});
		} else {
			await member.roles.remove(role).catch(err => {
				console.error('Failed to remove reaction role:', err);
			});
		}
	} catch (error) {
		console.error('handleReactionRoleUpdate failed:', error);
	}
}

function buildTicketModal(ticketType) {
	const definition = {
		partnerships: {
			title: 'Partnership ticket',
			fields: [
				{ id: 'server_name', label: 'Server naam', placeholder: 'Hoe heet jullie server?', required: true },
				{ id: 'member_count', label: 'Aantal leden', placeholder: 'Hoeveel leden hebben jullie?', required: true },
				{ id: 'discord_link', label: 'Discord link', placeholder: 'Plak de invite link', required: true },
				{ id: 'goal', label: 'Wat wil je bespreken?', placeholder: 'Wat zoek je in de partnership?', required: true },
			],
		},
		vragen: {
			title: 'Vragen ticket',
			fields: [
				{ id: 'question', label: 'Je vraag', placeholder: 'Waarmee kunnen we helpen?', required: true },
				{ id: 'context', label: 'Context', placeholder: 'Geef wat extra uitleg', required: false },
				{ id: 'priority', label: 'Prioriteit', placeholder: 'Laag, gemiddeld, hoog', required: false },
			],
		},
		twitch_promotie: {
			title: 'Twitch promotie ticket',
			fields: [
				{ id: 'twitch_name', label: 'Twitch naam', placeholder: 'Hoe heet je op Twitch?', required: true },
				{ id: 'stream_link', label: 'Stream link', placeholder: 'Link naar je stream', required: true },
				{ id: 'promotion_goal', label: 'Wat wil je promoten?', placeholder: 'Bijv. je stream of een event', required: true },
				{ id: 'extra', label: 'Extra info', placeholder: 'Aanvullende info', required: false },
			],
		},
		sollicitaties: {
			title: 'Sollicitatie ticket',
			fields: [
				{ id: 'name', label: 'Naam', placeholder: 'Hoe mogen we je noemen?', required: true },
				{ id: 'position', label: 'Positie', placeholder: 'Waar solliciteer je voor?', required: true },
				{ id: 'experience', label: 'Ervaring', placeholder: 'Welke ervaring heb je?', required: true },
				{ id: 'motivation', label: 'Motivatie', placeholder: 'Waarom wil je dit doen?', required: true },
			],
		},
	}[ticketType];

	if (!definition) {
		return null;
	}

	const modal = new ModalBuilder()
		.setCustomId(`ticketmodal:${ticketType}`)
		.setTitle(definition.title);

	for (const field of definition.fields) {
		const input = new TextInputBuilder()
			.setCustomId(field.id)
			.setLabel(field.label)
			.setStyle(TextInputStyle.Paragraph)
			.setRequired(Boolean(field.required));

		if (field.placeholder) {
			input.setPlaceholder(field.placeholder);
		}

		modal.addComponents(new ActionRowBuilder().addComponents(input));
	}

	return modal;
}

async function createTicketChannel(interaction, ticketType, fields) {
	const panelConfig = getGuildConfig(ticketPanelsFile, interaction.guildId, null);
	if (!panelConfig) {
		return null;
	}

	const supportRoleId = panelConfig.supportRoleId || null;
	const categoryId = panelConfig.categoryId || null;
	const safeName = interaction.user.username.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 20) || 'user';
	const channelName = `ticket-${ticketType}-${safeName}`.slice(0, 90);

	const overwrites = [
		{
			id: interaction.guild.roles.everyone.id,
			deny: [PermissionFlagsBits.ViewChannel],
		},
		{
			id: interaction.user.id,
			allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles, PermissionFlagsBits.EmbedLinks],
		},
		{
			id: interaction.client.user.id,
			allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageMessages],
		},
	];

	if (supportRoleId) {
		overwrites.push({
			id: supportRoleId,
			allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles, PermissionFlagsBits.EmbedLinks],
		});
	}

	const ticketChannel = await interaction.guild.channels.create({
		name: channelName,
		type: ChannelType.GuildText,
		parent: categoryId || undefined,
		topic: `ticket:${ticketType}:${interaction.user.id}`,
		permissionOverwrites: overwrites,
		reason: `Ticket created by ${interaction.user.tag}`,
	});

	const ticketEmbed = new EmbedBuilder()
		.setColor(0xb40f0f)
		.setTitle(`Ticket: ${ticketType}`)
		.setDescription(`Ticket aangemaakt door ${interaction.user}.`);

	for (const [key, value] of Object.entries(fields)) {
		ticketEmbed.addFields({ name: key.replace(/_/g, ' '), value: value || 'Geen antwoord', inline: false });
	}

	const pingText = supportRoleId ? `<@&${supportRoleId}>` : '';
	await ticketChannel.send({ content: `${pingText} ${interaction.user}`.trim(), embeds: [ticketEmbed] }).catch(err => {
		console.error('Failed to send ticket summary:', err);
	});

	return ticketChannel;
}

client.commands = new Collection();

const foldersPath = path.join(__dirname, 'commands');
const commandFolders = fs.readdirSync(foldersPath);


for (const folder of commandFolders) {
	const commandsPath = path.join(foldersPath, folder);
	const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
	for (const file of commandFiles) {
		const filePath = path.join(commandsPath, file);
		const command = require(filePath);
		// Set a new item in the Collection with the key as the command name and the value as the exported module
		if ('data' in command && 'execute' in command) {
			client.commands.set(command.data.name, command);
		} else {
			console.log(`[WARNING] The command at ${filePath} is missing a required "data" or "execute" property.`);
		}
	}
}

//Register our commands
deployCommands();


client.once(Events.ClientReady, c => {
	console.log(`Ready! Logged in as ${c.user.tag}`);
	try {
		const migrated = migrateGuildConfigs();
		if (migrated > 0) {
			console.log(`Migrated config for ${migrated} guild(s) into guildSettings.json`);
		}
	} catch (err) {
		console.error('Config migration failed:', err);
	}
});

client.on(Events.MessageCreate, async message => {
	try {
		if (!message.guild || message.author.bot) return;

		if (await handleCountingMessage(message)) {
			return;
		}

		if (await handleMinigameMessage(message)) {
			return;
		}

		const gainedXp = Math.floor(Math.random() * (xpPerMessageMax - xpPerMessageMin + 1)) + xpPerMessageMin;
		await processLevelGain({
			guild: message.guild,
			user: message.author,
			member: message.member,
			amount: gainedXp,
			levelsFile,
			rewardsFile,
			levelsChannelFile,
			updateLastMessageAt: true,
		});

		await maybeSpawnCrown(message);
	} catch (err) {
		console.error('messageCreate handler failed:', err);
	}
});

client.on(Events.GuildMemberAdd, async member => {
	try {
		await sendWelcomeMessage(member);
	} catch (error) {
		console.error('GuildMemberAdd handler failed:', error);
	}
});

client.on(Events.MessageReactionAdd, async (reaction, user) => {
	await handleReactionRoleUpdate(reaction, user, true);
});

client.on(Events.MessageReactionRemove, async (reaction, user) => {
	await handleReactionRoleUpdate(reaction, user, false);
});

client.on(Events.InteractionCreate, async interaction => {
	try {
		const isWizardCandidate = interaction.customId && interaction.customId.startsWith('setup:') && (
			interaction.isButton?.() ||
			interaction.isStringSelectMenu?.() ||
			interaction.isChannelSelectMenu?.() ||
			interaction.isRoleSelectMenu?.() ||
			interaction.isModalSubmit?.()
		);
		if (isWizardCandidate) {
			await setupWizard.dispatch(interaction);
			return;
		}

		if (interaction.isButton()) {
			if (interaction.customId.startsWith('blackjack:')) {
				const [, gameId, action] = interaction.customId.split(':');
				const games = loadBlackjackGames();
				const state = games[gameId];

				if (!state || state.guildId !== interaction.guildId) {
					await interaction.reply({ content: 'Deze blackjack game bestaat niet meer.', flags: 64 });
					return;
				}

				if (state.userId !== interaction.user.id) {
					await interaction.reply({ content: 'Alleen de speler die de game startte kan dit doen.', flags: 64 });
					return;
				}

				if (state.finished) {
					await interaction.reply({ content: 'Deze blackjack game is al afgelopen.', flags: 64 });
					return;
				}

				if (action === 'hit') {
					await interaction.deferUpdate().catch(() => null);
					state.playerHand.push(drawCard(state.deck));
					games[gameId] = state;
					saveBlackjackGames(games);
					const targetMessage = await resolveBlackjackMessage(interaction);

					if (isBust(state.playerHand)) {
						const result = await settleBlackjackState(interaction, state, 'bust');
						await targetMessage.edit({ content: `Resultaat: je bent busted en verliest ${state.bet} kroontjes.`, embeds: [result.embed], components: result.components }).catch(error => {
							console.error('Failed to edit blackjack bust message:', error);
						});
						return;
					}

					await targetMessage.edit({
						content: 'Blackjack is nu draaiende. Gebruik Hit of Stand.',
						embeds: [buildBlackjackEmbed(state, false, 'Blackjack is nu draaiende. Gebruik Hit of Stand.')],
						components: [buildBlackjackButtons(gameId)],
					}).catch(error => {
						console.error('Failed to edit blackjack hit message:', error);
					});
					return;
				}

				if (action === 'stand') {
					await interaction.deferUpdate().catch(() => null);
					const targetMessage = await resolveBlackjackMessage(interaction);
					const result = await settleBlackjackState(interaction, state, 'stand');
					await targetMessage.edit({ content: `Resultaat: ${result.embed.data?.description || 'Blackjack afgerond.'}`, embeds: [result.embed], components: result.components }).catch(error => {
						console.error('Failed to edit blackjack stand message:', error);
					});
					return;
				}
			}

			if (interaction.customId.startsWith('crownclaim:')) {
				const claimId = interaction.customId.split(':')[1];
				const allClaims = readJson(crownsClaimsFile, {});
				const claim = allClaims[claimId];

				if (!claim || claim.guildId !== interaction.guildId) {
					await interaction.reply({ content: 'Dit kroontje bestaat niet meer.', flags: 64 });
					return;
				}

				if (claim.claimedBy) {
					await interaction.reply({ content: 'Dit kroontje is al geclaimd.', flags: 64 });
					return;
				}

				await interaction.deferUpdate().catch(() => null);
				claim.claimedBy = interaction.user.id;
				claim.claimedAt = Date.now();
				writeJson(crownsClaimsFile, allClaims);

				addBalance(crownsFile, interaction.guildId, interaction.user.id, 1);

				const disabledRow = new ActionRowBuilder().addComponents(
					new ButtonBuilder()
						.setCustomId(interaction.customId)
						.setLabel('Geclaimd')
						.setStyle(ButtonStyle.Success)
						.setDisabled(true),
				);

				await interaction.message.edit({ components: [disabledRow] }).catch(() => null);
				await interaction.followUp({ content: 'Je hebt 1 kroontje geclaimd!', ephemeral: true }).catch(() => null);
				return;
			}

			if (interaction.customId.startsWith('mg:ms:')) {
				const parts = interaction.customId.split(':');
				const gameId = parts[2];
				const action = parts[3];
				const state = minigameService.getActiveGame(interaction.guildId, interaction.channelId);
				if (!state || state.game !== 'minesweeper' || state.gameId !== gameId) {
					await interaction.reply({ content: 'Deze minesweeper-game bestaat niet meer.', flags: 64 });
					return;
				}
				if (state.starterId !== interaction.user.id) {
					await interaction.reply({ content: 'Alleen de speler kan dit bord bedienen.', flags: 64 });
					return;
				}

				if (action === 'flag') {
					state.flagMode = !state.flagMode;
					minigameService.setActiveGame(interaction.guildId, interaction.channelId, state);
					await interaction.update({
						embeds: [minigameService.buildMinesweeperEmbed(state)],
						components: minigameService.buildMinesweeperRows(state),
					}).catch(() => null);
					return;
				}

				if (action === 'stop') {
					state.finished = true;
					state.won = false;
					minigameService.setActiveGame(interaction.guildId, interaction.channelId, null);
					await interaction.update({
						embeds: [minigameService.buildMinesweeperEmbed(state)],
						components: minigameService.buildMinesweeperRows(state),
					}).catch(() => null);
					return;
				}

				const idx = Number(action);
				if (!Number.isInteger(idx) || idx < 0 || idx >= state.cells.length) {
					await interaction.reply({ content: 'Ongeldige cel.', flags: 64 });
					return;
				}
				const cell = state.cells[idx];
				if (cell.revealed) {
					await interaction.deferUpdate().catch(() => null);
					return;
				}

				if (state.flagMode) {
					cell.flagged = !cell.flagged;
				} else if (cell.flagged) {
					await interaction.deferUpdate().catch(() => null);
					return;
				} else if (cell.bomb) {
					cell.revealed = true;
					state.finished = true;
					state.won = false;
					minigameService.setActiveGame(interaction.guildId, interaction.channelId, null);
					await interaction.update({
						embeds: [minigameService.buildMinesweeperEmbed(state)],
						components: minigameService.buildMinesweeperRows(state),
					}).catch(() => null);
					return;
				} else {
					minigameService.revealMinesweeperFlood(state, idx);
					if (minigameService.checkMinesweeperWin(state)) {
						state.finished = true;
						state.won = true;
						const reward = await minigameService.awardWin(interaction.guildId, interaction.user.id, 'minesweeper');
						minigameService.setActiveGame(interaction.guildId, interaction.channelId, null);
						await interaction.update({
							embeds: [minigameService.buildMinesweeperEmbed(state)],
							components: minigameService.buildMinesweeperRows(state),
						}).catch(() => null);
						if (reward > 0) {
							await interaction.followUp({ content: `🎉 Je wint **${reward}** kroontjes!`, flags: 64 }).catch(() => null);
						}
						return;
					}
				}

				minigameService.setActiveGame(interaction.guildId, interaction.channelId, state);
				await interaction.update({
					embeds: [minigameService.buildMinesweeperEmbed(state)],
					components: minigameService.buildMinesweeperRows(state),
				}).catch(() => null);
				return;
			}

			if (interaction.customId.startsWith('rolecat:toggle:')) {
				const [, , categoryId, roleId] = interaction.customId.split(':');
				const category = roleCategoryService.getCategory(interaction.guildId, categoryId);
				if (!category) {
					await interaction.reply({ content: 'Deze categorie bestaat niet meer.', flags: 64 });
					return;
				}
				if (!category.roleIds.includes(roleId)) {
					await interaction.reply({ content: 'Deze rol zit niet meer in deze categorie.', flags: 64 });
					return;
				}

				const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
				if (!member) {
					await interaction.reply({ content: 'Kon je lid niet ophalen.', flags: 64 });
					return;
				}

				const hasRole = member.roles.cache.has(roleId);
				if (hasRole) {
					await member.roles.remove(roleId).catch(() => null);
					await interaction.reply({ content: `Rol <@&${roleId}> verwijderd.`, flags: 64 });
					return;
				}

				if (category.exclusive) {
					for (const otherRoleId of category.roleIds) {
						if (otherRoleId !== roleId && member.roles.cache.has(otherRoleId)) {
							await member.roles.remove(otherRoleId).catch(() => null);
						}
					}
				}

				await member.roles.add(roleId).catch(() => null);
				await interaction.reply({ content: `Rol <@&${roleId}> toegevoegd.`, flags: 64 });
				return;
			}

			if (interaction.customId.startsWith('ticketpanel:')) {
				const ticketType = interaction.customId.split(':')[1];
				const modal = buildTicketModal(ticketType);
				if (!modal) {
					await interaction.reply({ content: 'Onbekend tickettype.', flags: 64 });
					return;
				}

				await interaction.showModal(modal);
				return;
			}
		}

		if (interaction.isModalSubmit() && interaction.customId.startsWith('ticketmodal:')) {
			const ticketType = interaction.customId.split(':')[1];
			const fieldDefinitions = {
				partnerships: ['server_name', 'member_count', 'discord_link', 'goal'],
				vragen: ['question', 'context', 'priority'],
				twitch_promotie: ['twitch_name', 'stream_link', 'promotion_goal', 'extra'],
				sollicitaties: ['name', 'position', 'experience', 'motivation'],
			}[ticketType];

			if (!fieldDefinitions) {
				await interaction.reply({ content: 'Onbekend tickettype.', flags: 64 });
				return;
			}

			const ticketFields = {};
			for (const fieldId of fieldDefinitions) {
				ticketFields[fieldId] = interaction.fields.getTextInputValue(fieldId);
			}

			const ticketChannel = await createTicketChannel(interaction, ticketType, ticketFields);
			if (!ticketChannel) {
				await interaction.reply({ content: 'Kon ticket niet aanmaken.', flags: 64 });
				return;
			}

			await interaction.reply({ content: `Ticket aangemaakt: ${ticketChannel}`, flags: 64 });
			return;
		}

	if (interaction.isStringSelectMenu() && interaction.customId.startsWith('rolemenu:')) {
		const menuId = interaction.customId.split(':')[1];
		const allMenus = readJson(roleMenusFile, {});
		const menuConfig = allMenus[menuId];

		if (!menuConfig || menuConfig.guildId !== interaction.guildId) {
			await interaction.reply({ content: 'Dit rolmenu bestaat niet meer.', flags: 64 });
			return;
		}

		const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
		if (!member) {
			await interaction.reply({ content: 'Kon je lid niet ophalen.', flags: 64 });
			return;
		}

		const selectedRoleIds = new Set(interaction.values);
		const menuRoleIds = menuConfig.roles.map(role => role.roleId);

		for (const roleId of menuRoleIds) {
			if (selectedRoleIds.has(roleId)) {
				await member.roles.add(roleId).catch(() => null);
			} else {
				await member.roles.remove(roleId).catch(() => null);
			}
		}

		await interaction.reply({ content: 'Je rollen zijn bijgewerkt.', flags: 64 });
		return;
	}

		if (!interaction.isChatInputCommand()) return;

		const command = interaction.client.commands.get(interaction.commandName);

		if (!command) {
		console.error(`No command matching ${interaction.commandName} was found.`);
		return;
		}

		const restriction = checkCommandAllowed(interaction, interaction.commandName);
		if (!restriction.allowed) {
			await interaction.reply({ content: restriction.reason || 'Dit command is hier niet toegestaan.', flags: 64 }).catch(() => null);
			return;
		}

		try {
			await command.execute(interaction);
		} catch (error) {
			console.error(error);
			if (interaction.replied || interaction.deferred) {
				await interaction.followUp({ content: 'There was an error while executing this command!', flags: 64 });
			} else {
				await interaction.reply({ content: 'There was an error while executing this command!', flags: 64 });
			}
		}
	} catch (error) {
		console.error('InteractionCreate handler failed:', error);
	}
});

client.login(BOT_TOKEN);